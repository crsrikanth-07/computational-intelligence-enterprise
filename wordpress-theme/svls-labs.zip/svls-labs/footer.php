<footer class="site-footer band-dark">
  <div class="container">
    <div class="footer-top">
      <div class="footer__brand">
        <a href="/" class="brand" aria-label="SVLS LABS home">
          <svg class="brand__lockup" viewBox="0 0 316 64" aria-hidden="true" focusable="false">
            <path d="M4 24V4h20v4H8v16z" fill="currentColor"/>
            <circle cx="32" cy="32" r="13.5" fill="none" stroke="currentColor" stroke-width="5"/>
            <path d="M60 40v20H40v-4h16V40z" fill="var(--svls-accent, #E4432B)"/>
            <text x="80" y="60" fill="currentColor" font-family="'Inter Tight', Inter, 'Helvetica Neue', Helvetica, Arial, sans-serif" font-size="44" font-weight="700" letter-spacing="-0.44">SVLS LABS</text>
          </svg>
        </a>
        <p class="footer__strap">Architecture for Complex Enterprise Systems.</p>
        <p class="footer__founded">Founded 2020. Vendor-neutral enterprise architecture and software engineering.</p>
      </div>
      <nav id="site-nav" class="footer-nav" aria-label="Footer">
        <div class="footer__col">
          <p class="eyebrow">Services</p>
          <ul>
            <li><a href="/services/architecture/">Enterprise Architecture</a></li>
            <li><a href="/services/erp/">ERP &amp; Application Modernisation</a></li>
            <li><a href="/services/integration/">Integration &amp; Cloud</a></li>
            <li><a href="/services/ai/">AI &amp; Agentic Architecture</a></li>
            <li><a href="/services/engineering/">Software Engineering</a></li>
            <li><a href="/services/assessment/">Architecture Assessment</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <p class="eyebrow">Products and Method</p>
          <ul>
            <li><a href="/products/">Products</a></li>
            <li><a href="/products/value-lens/">Value Lens (private beta)</a></li>
            <li><a href="/approach/">Approach</a></li>
            <li><a href="/ai-governance/">AI Governance</a></li>
            <li><a href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/downloads/governed-agent-control-checklist.pdf">Agent control checklist (PDF)</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <p class="eyebrow">Company</p>
          <ul>
            <li><a href="/about/">About</a></li>
            <li><a href="/contact/">Contact</a></li>
            <li><a href="https://www.linkedin.com/company/svlslabs/" target="_blank" rel="noopener">LinkedIn<span class="visually-hidden"> (opens in a new tab)</span></a></li>
            <li><a href="/privacy/">Privacy</a></li>
            <li><a href="/terms/">Terms</a></li>
          </ul>
        </div>
      </nav>
    </div>
    <div class="footer-bottom">
      <p>&copy; <span data-year>2026</span> SVLS LABS LLP. Established 2020.</p>
      <p>4th Floor, Aparna Astute, Shaikpet, Door No. 8-1-299/103&amp;104/AA/4F-2, Jubilee Hills, Hyderabad 500008, Telangana, India<br><a href="mailto:service@svlslabs.com">service@svlslabs.com</a><br><a class="nowrap" href="tel:+918500811119">+91&nbsp;8500811119</a></p>
    </div>
    <p class="footer__status">Value Lens: private beta on synthetic ERP-like data. Production ERP connector in development.</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
