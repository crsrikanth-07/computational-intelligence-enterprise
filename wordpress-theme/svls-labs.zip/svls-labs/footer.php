<footer class="site-footer band-dark">
  <div class="container">
    <div class="footer-top">
      <div class="footer__brand">
        <a href="/" class="brand" aria-label="SVLS LABS home">
          <svg class="brand__lockup" viewBox="0 0 316 64" aria-hidden="true" focusable="false">
            <path d="M4 24V4h20v4H8v16z" fill="currentColor"/>
            <circle cx="32" cy="32" r="13.5" fill="none" stroke="currentColor" stroke-width="5"/>
            <path d="M60 40v20H40v-4h16V40z" fill="var(--svls-accent, #E4432B)"/>
            <text x="80" y="60" fill="currentColor" font-family="'Inter Tight', Inter, 'Helvetica Neue', Helvetica, Arial, sans-serif" font-size="44" font-weight="700" letter-spacing="-0.44">SVLS LABS</text>
          </svg>
        </a>
        <p class="footer__strap">Innovative Software for Enterprise and Entertainment.</p>
        <p class="footer__founded">Founded 2020. Two portfolios: Enterprise Software and Entertainment &amp; Media.</p>
      </div>
      <nav id="site-nav" class="footer-nav" aria-label="Footer">
        <div class="footer__col">
          <p class="eyebrow">Enterprise</p>
          <ul>
            <li><a href="/services/sap/">ERP</a></li>
            <li><a href="/services/cloud/">Cloud</a></li>
            <li><a href="/services/ai/">Agentic &amp; Applied AI</a></li>
            <li><a href="/services/ai/#methods">Applied AI research</a></li>
            <li><a href="/approach/">Approach</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <p class="eyebrow">Products</p>
          <ul>
            <li><a href="/products/cutti/">CuTTI (flagship)</a></li>
            <li><a href="/products/value-lens/">Value Lens (flagship)</a></li>
            <li><a href="/products/cutti/#early-access">CuTTI early access</a></li>
            <li><a href="/products/value-lens/#beta">Value Lens beta access</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <p class="eyebrow">Company</p>
          <ul>
            <li><a href="/about/">About</a></li>
            <li><a href="/media/">Entertainment &amp; Media</a></li>
            <li><a href="/contact/">Contact</a></li>
            <li><a href="https://www.linkedin.com/company/svlslabs/" target="_blank" rel="noopener">LinkedIn<span class="visually-hidden"> (opens in a new tab)</span></a></li>
            <li><a href="/privacy/">Privacy</a></li>
            <li><a href="/terms/">Terms</a></li>
          </ul>
        </div>
      </nav>
    </div>
    <div class="footer-bottom">
      <p>&copy; <span data-year>2026</span> SVLS LABS LLP. Established 2020.</p>
      <p>4th Floor, Aparna Astute, Shaikpet, Door No. 8-1-299/103&amp;104/AA/4F-2, Jubilee Hills, Hyderabad 500008, Telangana, India<br><a href="mailto:service@svlslabs.com">service@svlslabs.com</a><br><a class="nowrap" href="tel:+918500811119">+91&nbsp;8500811119</a></p>
    </div>
    <p class="footer__status">CuTTI: available to purchase from 1 January 2027. Value Lens: private beta.</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
