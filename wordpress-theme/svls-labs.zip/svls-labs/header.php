<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<?php svls_page_head(); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <div class="container site-header__inner">
    <a href="/" class="brand" aria-label="SVLS LABS home">
      <svg class="brand__lockup" viewBox="0 0 316 64" aria-hidden="true" focusable="false">
        <path d="M4 24V4h20v4H8v16z" fill="currentColor"/>
        <circle cx="32" cy="32" r="13.5" fill="none" stroke="currentColor" stroke-width="5"/>
        <path d="M60 40v20H40v-4h16V40z" fill="var(--svls-accent, #E4432B)"/>
        <text x="80" y="60" fill="currentColor" font-family="'Inter Tight', Inter, 'Helvetica Neue', Helvetica, Arial, sans-serif" font-size="44" font-weight="700" letter-spacing="-0.44">SVLS LABS</text>
      </svg>
      <svg class="brand__mark" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
        <path d="M4 24V4h20v4H8v16z" fill="currentColor"/><circle cx="32" cy="32" r="13.5" fill="none" stroke="currentColor" stroke-width="5"/><path d="M60 40v20H40v-4h16V40z" fill="var(--svls-accent, #E4432B)"/>
      </svg>
    </a>
    <nav class="site-nav" aria-label="Primary">
      <ul class="site-nav__list">
        <li class="site-nav__item has-dropdown">
          <button class="site-nav__link site-nav__trigger" type="button" aria-expanded="false" aria-controls="services-menu">Services<svg class="site-nav__chevron" viewBox="0 0 10 10" aria-hidden="true" focusable="false"><path d="M1 3.5l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></button>
          <ul class="dropdown" id="services-menu">
            <li><a href="/services/"<?php svls_current( '/services/' ); ?>><span class="dropdown__title">All services</span><span class="dropdown__desc">Six practices, one architecture standard</span></a></li>
            <li><a href="/services/architecture/"<?php svls_current( '/services/architecture/' ); ?>><span class="dropdown__title">Enterprise Architecture</span><span class="dropdown__desc">Future-state architecture, roadmaps and governance</span></a></li>
            <li><a href="/services/erp/"<?php svls_current( '/services/erp/' ); ?>><span class="dropdown__title">ERP &amp; Application Modernisation</span><span class="dropdown__desc">ERP strategy, legacy and custom-code modernisation</span></a></li>
            <li><a href="/services/integration/"<?php svls_current( '/services/integration/' ); ?>><span class="dropdown__title">Integration &amp; Cloud</span><span class="dropdown__desc">APIs, events, hybrid integration and cloud architecture</span></a></li>
            <li><a href="/services/ai/"<?php svls_current( '/services/ai/' ); ?>><span class="dropdown__title">AI &amp; Agentic Architecture</span><span class="dropdown__desc">Enterprise agents, tool governance, human in the loop</span></a></li>
            <li><a href="/services/engineering/"<?php svls_current( '/services/engineering/' ); ?>><span class="dropdown__title">Software Engineering</span><span class="dropdown__desc">Purpose-built enterprise applications and platforms</span></a></li>
            <li><a href="/services/assessment/"<?php svls_current( '/services/assessment/' ); ?>><span class="dropdown__title">Architecture Assessment</span><span class="dropdown__desc">Fixed-scope entry engagement</span></a></li>
          </ul>
        </li>
        <li class="site-nav__item"><a class="site-nav__link" href="/products/"<?php svls_current( '/products/' ); ?>>Products</a></li>
        <li class="site-nav__item"><a class="site-nav__link" href="/approach/"<?php svls_current( '/approach/' ); ?>>Approach</a></li>
        <li class="site-nav__item"><a class="site-nav__link" href="/ai-governance/"<?php svls_current( '/ai-governance/' ); ?>>AI Governance</a></li>
        <li class="site-nav__item"><a class="site-nav__link" href="/about/"<?php svls_current( '/about/' ); ?>>About</a></li>
        <li class="site-nav__item"><a class="site-nav__link" href="/contact/"<?php svls_current( '/contact/' ); ?>>Contact</a></li>
      </ul>
    </nav>
    <div class="site-header__actions">
      <a class="btn btn--primary btn--nav" href="/services/assessment/">Start an Assessment</a>
      <button class="theme-toggle" type="button" data-theme-toggle aria-label="Switch to dark theme">
        <svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><circle cx="10" cy="10" r="6.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10 3.5a6.5 6.5 0 0 1 0 13z" fill="currentColor"/></svg>
      </button>
      <a class="menu-btn" href="#site-nav" data-menu-toggle><span class="menu-btn__label">Menu</span><svg class="menu-btn__lines" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M0 2.5h16M0 8h16M0 13.5h16" fill="none" stroke="currentColor" stroke-width="1.5"/></svg><svg class="menu-btn__close" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M2 2l12 12M14 2L2 14" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></a>
    </div>
  </div>
</header>
<div class="sheet-backdrop" data-menu-backdrop hidden></div>
<div class="sheet" id="mobile-sheet" hidden>
  <nav aria-label="Menu">
    <ul class="sheet__list">
      <li>
        <span class="eyebrow sheet__group-label" id="sheet-services">Services</span>
        <ul class="sheet__sub" aria-labelledby="sheet-services">
          <li><a class="sheet__link" href="/services/"<?php svls_current( '/services/' ); ?>>All services</a></li>
          <li><a class="sheet__link" href="/services/architecture/"<?php svls_current( '/services/architecture/' ); ?>>Enterprise Architecture</a></li>
          <li><a class="sheet__link" href="/services/erp/"<?php svls_current( '/services/erp/' ); ?>>ERP &amp; Application Modernisation</a></li>
          <li><a class="sheet__link" href="/services/integration/"<?php svls_current( '/services/integration/' ); ?>>Integration &amp; Cloud</a></li>
          <li><a class="sheet__link" href="/services/ai/"<?php svls_current( '/services/ai/' ); ?>>AI &amp; Agentic Architecture</a></li>
          <li><a class="sheet__link" href="/services/engineering/"<?php svls_current( '/services/engineering/' ); ?>>Software Engineering</a></li>
          <li><a class="sheet__link" href="/services/assessment/"<?php svls_current( '/services/assessment/' ); ?>>Architecture Assessment</a></li>
        </ul>
      </li>
      <li><a class="sheet__link" href="/products/"<?php svls_current( '/products/' ); ?>>Products</a></li>
      <li><a class="sheet__link" href="/approach/"<?php svls_current( '/approach/' ); ?>>Approach</a></li>
      <li><a class="sheet__link" href="/ai-governance/"<?php svls_current( '/ai-governance/' ); ?>>AI Governance</a></li>
      <li><a class="sheet__link" href="/about/"<?php svls_current( '/about/' ); ?>>About</a></li>
      <li><a class="sheet__link" href="/contact/"<?php svls_current( '/contact/' ); ?>>Contact</a></li>
    </ul>
    <div class="sheet__actions">
      <a class="btn btn--primary" href="/services/assessment/">Start an Architecture Assessment</a>
      <a class="btn btn--secondary" href="/contact/?intent=discovery">Book a discovery call</a>
    </div>
  </nav>
  <div class="sheet__theme" role="group" aria-label="Appearance">
    <span class="sheet__theme-label" aria-hidden="true">Appearance:</span>
    <button type="button" class="chip" data-theme-choice="system" aria-pressed="true">System</button>
    <button type="button" class="chip" data-theme-choice="light" aria-pressed="false">Light</button>
    <button type="button" class="chip" data-theme-choice="dark" aria-pressed="false">Dark</button>
  </div>
</div>
