<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<?php svls_page_head(); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <div class="container site-header__inner">
    <a href="/" class="brand" aria-label="SVLS LABS home">
      <svg class="brand__lockup" viewBox="0 0 316 64" aria-hidden="true" focusable="false">
        <path d="M4 24V4h20v4H8v16z" fill="currentColor"/>
        <circle cx="32" cy="32" r="13.5" fill="none" stroke="currentColor" stroke-width="5"/>
        <path d="M60 40v20H40v-4h16V40z" fill="var(--svls-accent, #E4432B)"/>
        <text x="80" y="60" fill="currentColor" font-family="'Inter Tight', Inter, 'Helvetica Neue', Helvetica, Arial, sans-serif" font-size="44" font-weight="700" letter-spacing="-0.44">SVLS LABS</text>
      </svg>
      <svg class="brand__mark" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
        <path d="M4 24V4h20v4H8v16z" fill="currentColor"/>
        <circle cx="32" cy="32" r="13.5" fill="none" stroke="currentColor" stroke-width="5"/>
        <path d="M60 40v20H40v-4h16V40z" fill="var(--svls-accent, #E4432B)"/>
      </svg>
    </a>
    <nav class="site-nav" aria-label="Primary">
      <ul class="site-nav__list">
        <li class="site-nav__item has-dropdown">
          <button class="site-nav__link site-nav__trigger" type="button" aria-expanded="false" aria-controls="services-menu">Services<svg class="site-nav__chevron" viewBox="0 0 10 10" aria-hidden="true" focusable="false"><path d="M1 3.5l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></button>
          <ul class="dropdown" id="services-menu">
            <li><a href="/services/sap/"<?php svls_current( '/services/sap/' ); ?>><span class="dropdown__title">SAP &amp; ERP</span><span class="dropdown__desc">S/4HANA, RISE, BTP, Integration Suite, Clean Core</span></a></li>
            <li><a href="/services/cloud/"<?php svls_current( '/services/cloud/' ); ?>><span class="dropdown__title">Cloud</span><span class="dropdown__desc">SAP-to-cloud integration, migrations, cloud-native engineering</span></a></li>
            <li><a href="/services/ai/"<?php svls_current( '/services/ai/' ); ?>><span class="dropdown__title">Agentic &amp; Applied AI</span><span class="dropdown__desc">Governed agents on SAP BTP, applied AI methods, AI-assisted engineering</span></a></li>
          </ul>
        </li>
        <li class="site-nav__item has-dropdown">
          <button class="site-nav__link site-nav__trigger" type="button" aria-expanded="false" aria-controls="products-menu">Products<svg class="site-nav__chevron" viewBox="0 0 10 10" aria-hidden="true" focusable="false"><path d="M1 3.5l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></button>
          <ul class="dropdown" id="products-menu">
            <li><a href="/products/value-lens/"<?php svls_current( '/products/value-lens/' ); ?>><span class="dropdown__title">Value Lens <span class="nav-beta">Private beta</span></span><span class="dropdown__desc">Margin leak finder for order-to-cash. Private beta.</span></a></li>
            <li><a href="/products/sap-intelligence-suite/"<?php svls_current( '/products/sap-intelligence-suite/' ); ?>><span class="dropdown__title">SAP Intelligence Suite</span><span class="dropdown__desc">AI-assisted SAP engineering workbench.</span></a></li>
            <li><a href="/products/logicpilot/"<?php svls_current( '/products/logicpilot/' ); ?>><span class="dropdown__title">LogicPilot <span class="nav-beta nav-beta--new">New</span></span><span class="dropdown__desc">MCP production assistant for Logic Pro. Launching 12 November 2026.</span></a></li>
          </ul>
        </li>
        <li class="site-nav__item"><a class="site-nav__link" href="/approach/"<?php svls_current( '/approach/' ); ?>>Approach</a></li>
        <li class="site-nav__item"><a class="site-nav__link" href="/about/"<?php svls_current( '/about/' ); ?>>About</a></li>
        <li class="site-nav__item"><a class="site-nav__link" href="/contact/"<?php svls_current( '/contact/' ); ?>>Contact</a></li>
      </ul>
    </nav>
    <div class="site-header__actions">
      <a class="btn btn--primary btn--nav" href="/contact/?intent=discovery">Book a discovery call</a>
      <button class="theme-toggle" type="button" data-theme-toggle aria-label="Switch to dark theme">
        <svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><circle cx="10" cy="10" r="6.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10 3.5a6.5 6.5 0 0 1 0 13z" fill="currentColor"/></svg>
      </button>
      <a class="menu-btn" href="#site-nav" data-menu-toggle><span class="menu-btn__label">Menu</span><svg class="menu-btn__lines" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M0 2.5h16M0 8h16M0 13.5h16" fill="none" stroke="currentColor" stroke-width="1.5"/></svg><svg class="menu-btn__close" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M2 2l12 12M14 2L2 14" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></a>
    </div>
  </div>
</header>
<div class="sheet-backdrop" data-menu-backdrop hidden></div>
<div class="sheet" id="mobile-sheet" hidden>
  <nav aria-label="Menu">
    <ul class="sheet__list">
      <li>
        <span class="eyebrow sheet__group-label" id="sheet-services">Services</span>
        <ul class="sheet__sub" aria-labelledby="sheet-services">
          <li><a class="sheet__link" href="/services/sap/"<?php svls_current( '/services/sap/' ); ?>>SAP &amp; ERP</a></li>
          <li><a class="sheet__link" href="/services/cloud/"<?php svls_current( '/services/cloud/' ); ?>>Cloud</a></li>
          <li><a class="sheet__link" href="/services/ai/"<?php svls_current( '/services/ai/' ); ?>>Agentic &amp; Applied AI</a></li>
        </ul>
      </li>
      <li>
        <span class="eyebrow sheet__group-label" id="sheet-products">Products</span>
        <ul class="sheet__sub" aria-labelledby="sheet-products">
          <li><a class="sheet__link" href="/products/value-lens/"<?php svls_current( '/products/value-lens/' ); ?>>Value Lens <span class="nav-beta">Private beta</span></a></li>
          <li><a class="sheet__link" href="/products/sap-intelligence-suite/"<?php svls_current( '/products/sap-intelligence-suite/' ); ?>>SAP Intelligence Suite</a></li>
          <li><a class="sheet__link" href="/products/logicpilot/"<?php svls_current( '/products/logicpilot/' ); ?>>LogicPilot <span class="nav-beta nav-beta--new">New</span></a></li>
        </ul>
      </li>
      <li><a class="sheet__link" href="/approach/"<?php svls_current( '/approach/' ); ?>>Approach</a></li>
      <li><a class="sheet__link" href="/about/"<?php svls_current( '/about/' ); ?>>About</a></li>
      <li><a class="sheet__link" href="/contact/"<?php svls_current( '/contact/' ); ?>>Contact</a></li>
    </ul>
    <div class="sheet__actions">
      <a class="btn btn--primary" href="/contact/?intent=discovery">Book a discovery call</a>
      <a class="btn btn--secondary" href="/products/value-lens/#beta">Request Value Lens beta access</a>
    </div>
  </nav>
  <div class="sheet__theme" role="group" aria-label="Appearance">
    <span class="sheet__theme-label" aria-hidden="true">Appearance:</span>
    <button type="button" class="chip" data-theme-choice="system" aria-pressed="true">System</button>
    <button type="button" class="chip" data-theme-choice="light" aria-pressed="false">Light</button>
    <button type="button" class="chip" data-theme-choice="dark" aria-pressed="false">Dark</button>
  </div>
</div>
